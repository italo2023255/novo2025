export interface User {
  id: string;
  username: string;
  name: string;
  role: 'admin' | 'guard' | 'supervisor';
}

export interface Vehicle {
  id: string;
  plateNumber: string;
  model: string;
  status: 'available' | 'in-use' | 'maintenance';
  currentKm: number;
  lastMaintenanceKm: number;
  lastMaintenanceDate: string;
}

export interface Shift {
  id: string;
  vehicleId: string;
  startTime: string;
  endTime: string | null;
  startKm: number;
  endKm: number | null;
  driverId: string;
  driverName: string;
  crewMembers: string[];
  unitId: string;
  unitName: string;
  status: 'active' | 'completed';
  notes: string;
  checklist: VehicleChecklist;
  refuelings: Refueling[];
  photos: Photo[];
}

export interface VehicleChecklist {
  tires: boolean;
  windows: boolean;
  oil: boolean;
  damages: string;
}

export interface Refueling {
  id: string;
  shiftId: string;
  date: string;
  liters: number;
  totalCost: number;
  kmAtRefueling: number;
  fuelType: 'gasoline' | 'diesel' | 'ethanol';
  receiptPhoto?: string;
}

export interface Photo {
  id: string;
  shiftId: string;
  url: string;
  description: string;
  timestamp: string;
  type: 'start-shift' | 'end-shift' | 'damage' | 'other';
}

export interface Unit {
  id: string;
  name: string;
  code: string;
}
import React, { useState } from 'react';
import AppHeader from '../components/layout/AppHeader';
import Sidebar from '../components/layout/Sidebar';
import DashboardPage from '../pages/DashboardPage';
import VehiclesPage from '../pages/VehiclesPage';
import ShiftsPage from '../pages/ShiftsPage';

const AppLayout: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState('dashboard');
  
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };
  
  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    setIsSidebarOpen(false);
  };
  
  // Render current page based on state
  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'vehicles':
        return <VehiclesPage />;
      case 'shifts':
        return <ShiftsPage />;
      case 'reports':
        return (
          <div className="flex items-center justify-center min-h-[calc(100vh-4rem)] bg-gray-50">
            <div className="text-center">
              <h2 className="text-xl font-semibold text-gray-800">
                Página de Relatórios
              </h2>
              <p className="mt-2 text-gray-600">
                Esta funcionalidade estará disponível em breve.
              </p>
            </div>
          </div>
        );
      case 'maintenance':
        return (
          <div className="flex items-center justify-center min-h-[calc(100vh-4rem)] bg-gray-50">
            <div className="text-center">
              <h2 className="text-xl font-semibold text-gray-800">
                Página de Manutenção
              </h2>
              <p className="mt-2 text-gray-600">
                Esta funcionalidade estará disponível em breve.
              </p>
            </div>
          </div>
        );
      case 'users':
        return (
          <div className="flex items-center justify-center min-h-[calc(100vh-4rem)] bg-gray-50">
            <div className="text-center">
              <h2 className="text-xl font-semibold text-gray-800">
                Gerenciamento de Usuários
              </h2>
              <p className="mt-2 text-gray-600">
                Esta funcionalidade estará disponível em breve.
              </p>
            </div>
          </div>
        );
      case 'settings':
        return (
          <div className="flex items-center justify-center min-h-[calc(100vh-4rem)] bg-gray-50">
            <div className="text-center">
              <h2 className="text-xl font-semibold text-gray-800">
                Configurações do Sistema
              </h2>
              <p className="mt-2 text-gray-600">
                Esta funcionalidade estará disponível em breve.
              </p>
            </div>
          </div>
        );
      default:
        return <DashboardPage />;
    }
  };
  
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar 
        isOpen={isSidebarOpen} 
        currentPage={currentPage}
        onNavigate={handleNavigate}
      />
      
      <div className="flex flex-col flex-1 overflow-hidden">
        <AppHeader toggleSidebar={toggleSidebar} />
        
        <main className="flex-1 overflow-y-auto">
          {renderCurrentPage()}
        </main>
      </div>
      
      {/* Overlay for mobile sidebar */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-10 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        ></div>
      )}
    </div>
  );
};

export default AppLayout;
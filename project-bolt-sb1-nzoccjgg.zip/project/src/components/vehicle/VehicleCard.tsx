import React from 'react';
import { Calendar, BarChart2, Trash2 } from 'lucide-react';
import { Vehicle } from '../../types';
import Card, { CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';
import Badge from '../ui/Badge';
import Button from '../ui/Button';

interface VehicleCardProps {
  vehicle: Vehicle;
  onSelect: (vehicleId: string) => void;
  onDelete: (vehicleId: string) => void;
  isActive?: boolean;
}

const VehicleCard: React.FC<VehicleCardProps> = ({ 
  vehicle, 
  onSelect, 
  onDelete,
  isActive = false 
}) => {
  // Determine status color
  const getStatusBadge = () => {
    switch (vehicle.status) {
      case 'available':
        return <Badge variant="success">Disponível</Badge>;
      case 'in-use':
        return <Badge variant="primary">Em Uso</Badge>;
      case 'maintenance':
        return <Badge variant="warning">Em Manutenção</Badge>;
      default:
        return <Badge>Indisponível</Badge>;
    }
  };

  // Calculate KM since last maintenance
  const kmSinceLastMaintenance = vehicle.currentKm - vehicle.lastMaintenanceKm;
  
  // Determine if maintenance is needed soon (over 4500 km since last maintenance)
  const maintenanceNeeded = kmSinceLastMaintenance > 4500;

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Tem certeza que deseja excluir esta viatura?')) {
      onDelete(vehicle.id);
    }
  };
  
  return (
    <Card 
      className={`transition-all duration-200 hover:shadow-lg ${
        isActive ? 'ring-2 ring-blue-500 shadow-md' : ''
      }`}
    >
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle>{vehicle.model}</CardTitle>
          {getStatusBadge()}
        </div>
        <p className="text-sm font-semibold text-gray-500 mt-1">
          Placa: {vehicle.plateNumber}
        </p>
      </CardHeader>
      
      <CardContent className="pt-3">
        <div className="grid grid-cols-2 gap-4">
          <div className="flex flex-col">
            <span className="text-sm text-gray-500">Km Atual</span>
            <span className="text-lg font-medium">{vehicle.currentKm.toLocaleString()} km</span>
          </div>
          
          <div className="flex flex-col">
            <div className="flex items-center">
              <span className="text-sm text-gray-500">Desde última manutenção</span>
              {maintenanceNeeded && (
                <span className="ml-2 h-2 w-2 rounded-full bg-red-500" title="Manutenção recomendada"></span>
              )}
            </div>
            <span className={`text-lg font-medium ${maintenanceNeeded ? 'text-red-600' : ''}`}>
              {kmSinceLastMaintenance.toLocaleString()} km
            </span>
          </div>
        </div>
        
        <div className="mt-4 grid grid-cols-2 gap-4">
          <div className="flex items-center text-sm text-gray-600">
            <Calendar size={16} className="mr-1" />
            <span>Última manutenção: {new Date(vehicle.lastMaintenanceDate).toLocaleDateString()}</span>
          </div>
          
          <div className="flex items-center text-sm text-gray-600">
            <BarChart2 size={16} className="mr-1" />
            <span>Consumo médio: ~9.8 km/l</span>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="bg-gray-50 flex justify-between">
        <Button 
          variant={vehicle.status === 'available' ? 'primary' : 'outline'} 
          onClick={() => onSelect(vehicle.id)}
          className="flex-1 mr-2"
          disabled={vehicle.status === 'maintenance'}
        >
          {vehicle.status === 'available' ? 'Iniciar Turno' : 
           vehicle.status === 'in-use' ? 'Ver Detalhes' : 'Indisponível'}
        </Button>
        
        <Button
          variant="danger"
          onClick={handleDelete}
          disabled={vehicle.status === 'in-use'}
          icon={<Trash2 size={16} />}
        >
          Excluir
        </Button>
      </CardFooter>
    </Card>
  );
};

export default VehicleCard;
import React, { useState } from 'react';
import { Car, Hash } from 'lucide-react';
import { useVehicle } from '../../context/VehicleContext';
import Input from '../ui/Input';
import Button from '../ui/Button';
import Card, { CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';

interface VehicleFormProps {
  onComplete: () => void;
  onCancel: () => void;
}

const VehicleForm: React.FC<VehicleFormProps> = ({ onComplete, onCancel }) => {
  const { addVehicle } = useVehicle();
  
  const [model, setModel] = useState('');
  const [plateNumber, setPlateNumber] = useState('');
  const [currentKm, setCurrentKm] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!model) {
      newErrors.model = 'Modelo é obrigatório';
    }
    
    if (!plateNumber) {
      newErrors.plateNumber = 'Placa é obrigatória';
    } else if (!/^[A-Z]{3}-\d{4}$/.test(plateNumber)) {
      newErrors.plateNumber = 'Formato inválido. Use o formato: ABC-1234';
    }
    
    if (!currentKm) {
      newErrors.currentKm = 'Quilometragem atual é obrigatória';
    } else if (parseInt(currentKm) < 0) {
      newErrors.currentKm = 'Quilometragem não pode ser negativa';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      await addVehicle({
        model,
        plateNumber: plateNumber.toUpperCase(),
        currentKm: parseInt(currentKm),
      });
      
      onComplete();
    } catch (error) {
      console.error('Error adding vehicle:', error);
      setErrors({ submit: 'Ocorreu um erro ao cadastrar a viatura. Tente novamente.' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Nova Viatura</CardTitle>
      </CardHeader>
      
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <Input
            label="Modelo"
            value={model}
            onChange={(e) => setModel(e.target.value)}
            placeholder="Ex: Toyota Hilux"
            required
            fullWidth
            icon={<Car size={18} />}
            error={errors.model}
          />
          
          <Input
            label="Placa"
            value={plateNumber}
            onChange={(e) => setPlateNumber(e.target.value)}
            placeholder="Ex: GCM-1234"
            required
            fullWidth
            icon={<Hash size={18} />}
            error={errors.plateNumber}
          />
          
          <Input
            label="Quilometragem Atual"
            type="number"
            value={currentKm}
            onChange={(e) => setCurrentKm(e.target.value)}
            placeholder="Ex: 45000"
            required
            fullWidth
            error={errors.currentKm}
          />
          
          {errors.submit && (
            <div className="bg-red-50 p-3 rounded-md text-red-700 text-sm">
              {errors.submit}
            </div>
          )}
        </CardContent>
        
        <CardFooter className="flex justify-end space-x-3">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isLoading}
          >
            Cancelar
          </Button>
          <Button
            type="submit"
            variant="primary"
            disabled={isLoading}
          >
            {isLoading ? 'Cadastrando...' : 'Cadastrar Viatura'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default VehicleForm;
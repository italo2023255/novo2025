import React from 'react';

interface PageContainerProps {
  title: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
}

const PageContainer: React.FC<PageContainerProps> = ({ title, children, actions }) => {
  return (
    <div className="bg-gray-50 min-h-[calc(100vh-4rem)] p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
          {actions && <div>{actions}</div>}
        </div>
        {children}
      </div>
    </div>
  );
};

export default PageContainer;
import React from 'react';
import { Car, Clipboard, Home, Activity, Users, Settings, FileText } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  isOpen: boolean;
  currentPage: string;
  onNavigate: (page: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, currentPage, onNavigate }) => {
  const { user } = useAuth();
  
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <Home size={20} /> },
    { id: 'vehicles', label: 'Viaturas', icon: <Car size={20} /> },
    { id: 'shifts', label: 'Turnos', icon: <Clipboard size={20} /> },
    { id: 'reports', label: 'Relatórios', icon: <FileText size={20} /> },
    { id: 'maintenance', label: 'Manutenção', icon: <Activity size={20} /> },
  ];
  
  // Only show these items for admin users
  const adminItems = [
    { id: 'users', label: 'Usuários', icon: <Users size={20} /> },
    { id: 'settings', label: 'Configurações', icon: <Settings size={20} /> },
  ];
  
  // Combine items based on user role
  const menuItems = user?.role === 'admin' 
    ? [...navItems, ...adminItems] 
    : navItems;
  
  return (
    <aside
      className={`
        bg-blue-800 text-white w-64 fixed inset-y-0 left-0 z-20
        transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        md:translate-x-0 md:static flex flex-col
      `}
    >
      <div className="h-16 flex items-center justify-center border-b border-blue-700">
        <h2 className="text-xl font-bold">GCM Viatura</h2>
      </div>
      
      <nav className="flex-1 py-4 overflow-y-auto">
        <ul className="space-y-1 px-2">
          {menuItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => onNavigate(item.id)}
                className={`
                  w-full flex items-center space-x-3 px-3 py-2 rounded-md transition-colors
                  ${
                    currentPage === item.id
                      ? 'bg-blue-900 text-white'
                      : 'text-blue-100 hover:bg-blue-700'
                  }
                `}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-blue-700">
        <div className="flex items-center space-x-3">
          <div className="h-10 w-10 rounded-full bg-blue-700 flex items-center justify-center">
            <span className="text-lg font-medium">
              {user?.name?.charAt(0) || 'U'}
            </span>
          </div>
          <div>
            <p className="text-sm font-medium">{user?.name || 'Usuário'}</p>
            <p className="text-xs text-blue-300">
              {user?.role === 'admin' ? 'Administrador' : user?.role === 'supervisor' ? 'Supervisor' : 'Guarda Civil'}
            </p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
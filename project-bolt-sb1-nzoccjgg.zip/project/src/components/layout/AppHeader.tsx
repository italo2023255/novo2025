import React from 'react';
import { Menu, LogOut, Bell, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface AppHeaderProps {
  toggleSidebar: () => void;
}

const AppHeader: React.FC<AppHeaderProps> = ({ toggleSidebar }) => {
  const { user, logout } = useAuth();

  return (
    <header className="bg-blue-900 text-white shadow-md">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center">
          <button
            className="p-1 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-white md:hidden"
            onClick={toggleSidebar}
          >
            <Menu size={24} />
          </button>
          <div className="ml-4 md:ml-0 flex items-center">
            <div className="flex items-center">
              <svg
                className="h-8 w-8 text-white"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
              <h1 className="ml-2 text-xl font-bold">
                Controle de ViatuRAS GUARDA CIVIL MUNICIPAL DE PARÁ DE MINAS
              </h1>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <button className="p-1 rounded-md text-white hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-white">
            <Bell size={20} />
          </button>

          <div className="relative group">
            <button className="flex items-center space-x-1 focus:outline-none">
              <div className="flex items-center space-x-2">
                <div className="h-8 w-8 rounded-full bg-blue-700 flex items-center justify-center">
                  <User size={18} />
                </div>
                <span className="text-sm font-medium hidden md:block">
                  {user?.name || 'Usuário'}
                </span>
              </div>
            </button>

            <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
              <a
                href="#perfil"
                className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
              >
                Perfil
              </a>
              <a
                href="#configuracoes"
                className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
              >
                Configurações
              </a>
              <button
                onClick={logout}
                className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
              >
                <div className="flex items-center">
                  <LogOut size={16} className="mr-2" />
                  <span>Sair</span>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default AppHeader;

import React from 'react';
import { Clock, MapPin, User, Users, Fuel, AlertTriangle } from 'lucide-react';
import { Shift, Vehicle } from '../../types';
import Card, { CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';
import Button from '../ui/Button';
import Badge from '../ui/Badge';

interface ActiveShiftCardProps {
  shift: Shift;
  vehicle: Vehicle;
  onEnd: () => void;
  onRefuel: () => void;
  onAddPhoto: () => void;
}

const ActiveShiftCard: React.FC<ActiveShiftCardProps> = ({
  shift,
  vehicle,
  onEnd,
  onRefuel,
  onAddPhoto,
}) => {
  // Format date and calculate duration
  const startDate = new Date(shift.startTime);
  const formattedStartDate = startDate.toLocaleDateString();
  const formattedStartTime = startDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  
  // Calculate shift duration
  const now = new Date();
  const durationMs = now.getTime() - startDate.getTime();
  const durationHours = Math.floor(durationMs / (1000 * 60 * 60));
  const durationMinutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
  
  // Format duration
  const durationText = `${durationHours}h ${durationMinutes}m`;
  
  // Long duration warning (shifts > 8 hours)
  const isLongShift = durationHours >= 8;
  
  return (
    <Card className="bg-gradient-to-br from-blue-50 to-white border-l-4 border-blue-500">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle>Turno Ativo</CardTitle>
          <Badge variant="primary">Em Andamento</Badge>
        </div>
        <p className="text-sm font-semibold text-gray-500 mt-1">
          {vehicle.model} - {vehicle.plateNumber}
        </p>
      </CardHeader>
      
      <CardContent className="pt-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col space-y-4">
            <div className="flex items-start">
              <Clock size={18} className="mt-0.5 mr-2 text-blue-800" />
              <div>
                <p className="text-sm text-gray-500">Início do Turno</p>
                <p className="font-medium">
                  {formattedStartDate}, {formattedStartTime}
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <MapPin size={18} className="mt-0.5 mr-2 text-blue-800" />
              <div>
                <p className="text-sm text-gray-500">Odômetro Inicial</p>
                <p className="font-medium">{shift.startKm.toLocaleString()} km</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <User size={18} className="mt-0.5 mr-2 text-blue-800" />
              <div>
                <p className="text-sm text-gray-500">Condutor</p>
                <p className="font-medium">{shift.driverName}</p>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col space-y-4">
            <div className="flex items-start">
              <div className="flex items-center">
                <Clock size={18} className="mr-2 text-blue-800" />
                <p className="text-sm text-gray-500">Duração atual:</p>
              </div>
              <div className="ml-2">
                <p className={`font-bold ${isLongShift ? 'text-amber-600' : 'text-blue-800'}`}>
                  {durationText}
                  {isLongShift && (
                    <span className="inline-flex items-center ml-2" title="Turno longo">
                      <AlertTriangle size={14} className="text-amber-600" />
                    </span>
                  )}
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Users size={18} className="mt-0.5 mr-2 text-blue-800" />
              <div>
                <p className="text-sm text-gray-500">Grupamento</p>
                <p className="font-medium">{shift.unitName}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Fuel size={18} className="mt-0.5 mr-2 text-blue-800" />
              <div>
                <p className="text-sm text-gray-500">Abastecimentos</p>
                <p className="font-medium">
                  {shift.refuelings.length === 0 
                    ? 'Nenhum abastecimento registrado' 
                    : `${shift.refuelings.length} abastecimento(s)`}
                </p>
              </div>
            </div>
          </div>
        </div>
        
        {shift.notes && (
          <div className="mt-4 p-3 bg-gray-50 rounded-md">
            <p className="text-sm font-medium text-gray-700">Observações:</p>
            <p className="text-sm text-gray-600 mt-1">{shift.notes}</p>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
        <Button 
          variant="outline" 
          className="flex-1" 
          onClick={onRefuel}
        >
          <Fuel size={16} className="mr-1" />
          Registrar Abastecimento
        </Button>
        <Button 
          variant="outline" 
          className="flex-1" 
          onClick={onAddPhoto}
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1">
            <path strokeLinecap="round" strokeLinejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z" />
            <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0zM18.75 10.5h.008v.008h-.008V10.5z" />
          </svg>
          Adicionar Foto
        </Button>
        <Button 
          variant="danger" 
          className="w-full sm:w-auto" 
          onClick={onEnd}
        >
          Finalizar Turno
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ActiveShiftCard;
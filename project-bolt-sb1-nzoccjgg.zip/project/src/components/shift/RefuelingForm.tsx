import React, { useState } from 'react';
import { Droplet, DollarSign, Calendar, Camera } from 'lucide-react';
import { Shift, Vehicle } from '../../types';
import { useVehicle } from '../../context/VehicleContext';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Button from '../ui/Button';
import Card, { CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';

interface RefuelingFormProps {
  shift: Shift;
  vehicle: Vehicle;
  onComplete: () => void;
  onCancel: () => void;
}

const RefuelingForm: React.FC<RefuelingFormProps> = ({ 
  shift, 
  vehicle, 
  onComplete, 
  onCancel 
}) => {
  const { addRefueling } = useVehicle();
  
  const [kmAtRefueling, setKmAtRefueling] = useState<string>(vehicle.currentKm.toString());
  const [liters, setLiters] = useState<string>('');
  const [totalCost, setTotalCost] = useState<string>('');
  const [fuelType, setFuelType] = useState<'gasoline' | 'diesel' | 'ethanol'>('gasoline');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // For receipt photo upload simulation
  const [receiptPhotoUploaded, setReceiptPhotoUploaded] = useState<boolean>(false);
  
  // Calculate current time in the format expected by datetime-local input
  const getCurrentDateTime = () => {
    const now = new Date();
    return now.toISOString().slice(0, 16);
  };
  
  const [refuelingDate, setRefuelingDate] = useState<string>(getCurrentDateTime());
  
  const fuelTypeOptions = [
    { value: 'gasoline', label: 'Gasolina' },
    { value: 'diesel', label: 'Diesel' },
    { value: 'ethanol', label: 'Etanol' },
  ];
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!kmAtRefueling) {
      newErrors.kmAtRefueling = 'KM no momento do abastecimento é obrigatório';
    } else if (parseInt(kmAtRefueling) < shift.startKm) {
      newErrors.kmAtRefueling = `KM não pode ser menor que o KM inicial (${shift.startKm})`;
    }
    
    if (!liters) {
      newErrors.liters = 'Quantidade de litros é obrigatória';
    } else if (parseFloat(liters) <= 0) {
      newErrors.liters = 'Quantidade de litros deve ser maior que zero';
    }
    
    if (!totalCost) {
      newErrors.totalCost = 'Valor total é obrigatório';
    } else if (parseFloat(totalCost) <= 0) {
      newErrors.totalCost = 'Valor total deve ser maior que zero';
    }
    
    if (!refuelingDate) {
      newErrors.refuelingDate = 'Data do abastecimento é obrigatória';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Create refueling data
      const refuelingData = {
        shiftId: shift.id,
        date: refuelingDate,
        liters: parseFloat(liters),
        totalCost: parseFloat(totalCost),
        kmAtRefueling: parseInt(kmAtRefueling),
        fuelType,
        receiptPhoto: receiptPhotoUploaded 
          ? 'https://images.pexels.com/photos/1527934/pexels-photo-1527934.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
          : undefined,
      };
      
      // Add refueling record
      await addRefueling(shift.id, refuelingData);
      
      // Call the onComplete callback
      onComplete();
    } catch (error) {
      console.error('Error adding refueling:', error);
      setErrors({ submit: 'Ocorreu um erro ao registrar o abastecimento. Tente novamente.' });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Simulate receipt photo upload
  const handleReceiptPhotoUpload = () => {
    setReceiptPhotoUploaded(true);
  };
  
  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Registrar Abastecimento - {vehicle.model} ({vehicle.plateNumber})</CardTitle>
      </CardHeader>
      
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Data e Hora"
              type="datetime-local"
              value={refuelingDate}
              onChange={(e) => setRefuelingDate(e.target.value)}
              required
              fullWidth
              icon={<Calendar size={18} />}
              error={errors.refuelingDate}
            />
            
            <Input
              label="KM no Abastecimento"
              type="number"
              value={kmAtRefueling}
              onChange={(e) => setKmAtRefueling(e.target.value)}
              placeholder="Odômetro atual"
              required
              fullWidth
              error={errors.kmAtRefueling}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              label="Quantidade (Litros)"
              type="number"
              value={liters}
              onChange={(e) => setLiters(e.target.value)}
              placeholder="Ex: 45.5"
              required
              fullWidth
              step="0.01"
              icon={<Droplet size={18} />}
              error={errors.liters}
            />
            
            <Input
              label="Valor Total (R$)"
              type="number"
              value={totalCost}
              onChange={(e) => setTotalCost(e.target.value)}
              placeholder="Ex: 350.00"
              required
              fullWidth
              step="0.01"
              icon={<DollarSign size={18} />}
              error={errors.totalCost}
            />
            
            <Select
              label="Tipo de Combustível"
              options={fuelTypeOptions}
              value={fuelType}
              onChange={(value) => setFuelType(value as 'gasoline' | 'diesel' | 'ethanol')}
              required
              fullWidth
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Comprovante (Opcional)
            </label>
            <div 
              className={`
                border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center
                ${receiptPhotoUploaded ? 'border-green-300 bg-green-50' : 'border-gray-300 hover:border-blue-400'}
                transition-colors cursor-pointer
              `}
              onClick={handleReceiptPhotoUpload}
            >
              {receiptPhotoUploaded ? (
                <>
                  <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center text-green-600 mb-2">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                    </svg>
                  </div>
                  <p className="text-sm font-medium text-green-600">Comprovante enviado com sucesso</p>
                  <p className="text-xs text-gray-500 mt-1">Clique para alterar o comprovante</p>
                </>
              ) : (
                <>
                  <Camera className="h-10 w-10 text-gray-400 mb-2" />
                  <p className="text-sm font-medium text-gray-700">Foto do Comprovante</p>
                  <p className="text-xs text-gray-500 mt-1">Clique para tirar uma foto do comprovante</p>
                </>
              )}
            </div>
          </div>
          
          {errors.submit && (
            <div className="bg-red-50 p-3 rounded-md text-red-700 text-sm">
              {errors.submit}
            </div>
          )}
        </CardContent>
        
        <CardFooter className="flex justify-end space-x-3">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isLoading}
          >
            Cancelar
          </Button>
          <Button
            type="submit"
            variant="primary"
            disabled={isLoading}
          >
            {isLoading ? 'Registrando...' : 'Registrar Abastecimento'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default RefuelingForm;
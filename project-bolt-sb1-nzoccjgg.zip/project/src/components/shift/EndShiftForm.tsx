import React, { useState } from 'react';
import { Camera, Clock, MapPin } from 'lucide-react';
import { Shift, Vehicle, Photo } from '../../types';
import { useVehicle } from '../../context/VehicleContext';
import Input from '../ui/Input';
import Button from '../ui/Button';
import Card, { CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';

interface EndShiftFormProps {
  shift: Shift;
  vehicle: Vehicle;
  onComplete: () => void;
  onCancel: () => void;
}

const EndShiftForm: React.FC<EndShiftFormProps> = ({ 
  shift, 
  vehicle, 
  onComplete, 
  onCancel 
}) => {
  const { endShift } = useVehicle();
  
  const [endKm, setEndKm] = useState<string>(vehicle.currentKm.toString());
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // For photo upload simulation
  const [photoUploaded, setPhotoUploaded] = useState<boolean>(false);
  
  // Calculate current time in the format expected by datetime-local input
  const getCurrentDateTime = () => {
    const now = new Date();
    return now.toISOString().slice(0, 16);
  };
  
  const [endTime, setEndTime] = useState<string>(getCurrentDateTime());
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!endKm) {
      newErrors.endKm = 'KM final é obrigatório';
    } else if (parseInt(endKm) < shift.startKm) {
      newErrors.endKm = `KM final não pode ser menor que o KM inicial (${shift.startKm})`;
    }
    
    if (!endTime) {
      newErrors.endTime = 'Horário final é obrigatório';
    } else {
      const endDate = new Date(endTime);
      const startDate = new Date(shift.startTime);
      
      if (endDate < startDate) {
        newErrors.endTime = 'Horário final não pode ser anterior ao horário inicial';
      }
    }
    
    if (!photoUploaded) {
      newErrors.photo = 'Foto final da viatura é obrigatória';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Generate end photos
      const photos: Photo[] = [
        {
          id: `photo_end_${Date.now()}`,
          shiftId: shift.id,
          url: 'https://images.pexels.com/photos/2467285/pexels-photo-2467285.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
          description: 'Foto final da viatura',
          timestamp: new Date().toISOString(),
          type: 'end-shift',
        },
      ];
      
      // End the shift
      await endShift(shift.id, {
        endTime,
        endKm: parseInt(endKm),
        photos,
      });
      
      // Call the onComplete callback
      onComplete();
    } catch (error) {
      console.error('Error ending shift:', error);
      setErrors({ submit: 'Ocorreu um erro ao finalizar o turno. Tente novamente.' });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Simulate photo upload
  const handlePhotoUpload = () => {
    setPhotoUploaded(true);
  };
  
  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Finalizar Turno - {vehicle.model} ({vehicle.plateNumber})</CardTitle>
      </CardHeader>
      
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="KM Final"
              type="number"
              value={endKm}
              onChange={(e) => setEndKm(e.target.value)}
              placeholder="Odômetro atual"
              required
              fullWidth
              icon={<MapPin size={18} />}
              error={errors.endKm}
            />
            
            <Input
              label="Horário de Término"
              type="datetime-local"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
              required
              fullWidth
              icon={<Clock size={18} />}
              error={errors.endTime}
            />
          </div>
          
          <div>
            <div className="flex mb-4 p-3 bg-blue-50 rounded-md">
              <div className="mr-3 text-blue-700">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
                </svg>
              </div>
              <div>
                <p className="text-sm font-medium text-blue-800">Resumo do Turno</p>
                <p className="text-sm text-blue-700">
                  Início: {new Date(shift.startTime).toLocaleString()} | KM Inicial: {shift.startKm}
                </p>
                <p className="text-sm text-blue-700 mt-1">
                  Condutor: {shift.driverName} | Grupamento: {shift.unitName}
                </p>
              </div>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Foto Final da Viatura
            </label>
            <div 
              className={`
                border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center
                ${photoUploaded ? 'border-green-300 bg-green-50' : 'border-gray-300 hover:border-blue-400'}
                transition-colors cursor-pointer
              `}
              onClick={handlePhotoUpload}
            >
              {photoUploaded ? (
                <>
                  <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center text-green-600 mb-2">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                    </svg>
                  </div>
                  <p className="text-sm font-medium text-green-600">Foto enviada com sucesso</p>
                  <p className="text-xs text-gray-500 mt-1">Clique para alterar a foto</p>
                </>
              ) : (
                <>
                  <Camera className="h-10 w-10 text-gray-400 mb-2" />
                  <p className="text-sm font-medium text-gray-700">Tire uma foto da viatura</p>
                  <p className="text-xs text-gray-500 mt-1">Clique para abrir a câmera</p>
                </>
              )}
            </div>
            {errors.photo && <p className="mt-1 text-sm text-red-600">{errors.photo}</p>}
          </div>
          
          {errors.submit && (
            <div className="bg-red-50 p-3 rounded-md text-red-700 text-sm">
              {errors.submit}
            </div>
          )}
        </CardContent>
        
        <CardFooter className="flex justify-end space-x-3">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isLoading}
          >
            Cancelar
          </Button>
          <Button
            type="submit"
            variant="primary"
            disabled={isLoading}
          >
            {isLoading ? 'Finalizando...' : 'Finalizar Turno'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default EndShiftForm;
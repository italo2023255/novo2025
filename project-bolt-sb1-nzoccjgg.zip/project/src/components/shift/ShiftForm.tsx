import React, { useState } from 'react';
import { Camera, Clock, MapPin, Users } from 'lucide-react';
import { Vehicle, Unit, VehicleChecklist } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useVehicle } from '../../context/VehicleContext';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Button from '../ui/Button';
import Card, { CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';

interface ShiftFormProps {
  vehicle: Vehicle;
  onSubmit: () => void;
  onCancel: () => void;
}

const ShiftForm: React.FC<ShiftFormProps> = ({ vehicle, onSubmit, onCancel }) => {
  const { user } = useAuth();
  const { units, startShift } = useVehicle();
  
  const [startKm, setStartKm] = useState<string>(vehicle.currentKm.toString());
  const [notes, setNotes] = useState<string>('');
  const [unitId, setUnitId] = useState<string>(units[0]?.id || '');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // New fields
  const [driver, setDriver] = useState<string>('');
  const [selectedCrewMembers, setSelectedCrewMembers] = useState<string[]>([]);
  const [checklist, setChecklist] = useState<VehicleChecklist>({
    tires: false,
    windows: false,
    oil: false,
    damages: '',
  });
  
  // For photo upload simulation
  const [photoUploaded, setPhotoUploaded] = useState<boolean>(false);
  
  // Calculate current time in the format expected by datetime-local input
  const getCurrentDateTime = () => {
    const now = new Date();
    return now.toISOString().slice(0, 16);
  };
  
  const [startTime, setStartTime] = useState<string>(getCurrentDateTime());
  
  // Convert units to options format for the Select component
  const unitOptions = units.map(unit => ({
    value: unit.id,
    label: `${unit.name} (${unit.code})`,
  }));

  // GCM options
  const gcmOptions = [
    { value: 'DANTAS', label: 'DANTAS' },
    { value: 'SAUL', label: 'SAUL' },
    { value: 'GABRIEL', label: 'GABRIEL' },
  ];
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!startKm) {
      newErrors.startKm = 'KM inicial é obrigatório';
    } else if (parseInt(startKm) < vehicle.currentKm) {
      newErrors.startKm = `KM inicial não pode ser menor que o KM atual (${vehicle.currentKm})`;
    }
    
    if (!startTime) {
      newErrors.startTime = 'Horário inicial é obrigatório';
    }
    
    if (!unitId) {
      newErrors.unitId = 'Grupamento é obrigatório';
    }

    if (!driver) {
      newErrors.driver = 'Motorista é obrigatório';
    }

    if (!selectedCrewMembers.length) {
      newErrors.crewMembers = 'Selecione pelo menos um ocupante';
    }
    
    if (!photoUploaded) {
      newErrors.photo = 'Foto inicial da viatura é obrigatória';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Get the selected unit name
      const selectedUnit = units.find(u => u.id === unitId);
      
      // Create shift data object
      const shiftData = {
        vehicleId: vehicle.id,
        startTime,
        startKm: parseInt(startKm),
        driverId: user?.id || '',
        driverName: driver,
        crewMembers: selectedCrewMembers,
        unitId,
        unitName: selectedUnit?.name || '',
        notes,
        checklist,
        photos: [
          {
            url: 'https://images.pexels.com/photos/2467285/pexels-photo-2467285.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
            description: 'Foto inicial da viatura',
            timestamp: new Date().toISOString(),
            type: 'start-shift',
          },
        ],
      };
      
      // Call the startShift method from context
      await startShift(shiftData);
      
      // Call the onSubmit callback
      onSubmit();
    } catch (error) {
      console.error('Error starting shift:', error);
      setErrors({ submit: 'Ocorreu um erro ao iniciar o turno. Tente novamente.' });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Simulate photo upload
  const handlePhotoUpload = () => {
    setPhotoUploaded(true);
  };

  // Handle crew member selection
  const handleCrewMemberChange = (member: string) => {
    setSelectedCrewMembers(prev => {
      if (prev.includes(member)) {
        return prev.filter(m => m !== member);
      } else {
        return [...prev, member];
      }
    });
  };
  
  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Iniciar Turno - {vehicle.model} ({vehicle.plateNumber})</CardTitle>
      </CardHeader>
      
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="KM Inicial"
              type="number"
              value={startKm}
              onChange={(e) => setStartKm(e.target.value)}
              placeholder="Odômetro atual"
              required
              fullWidth
              icon={<MapPin size={18} />}
              error={errors.startKm}
            />
            
            <Input
              label="Horário de Início"
              type="datetime-local"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              required
              fullWidth
              icon={<Clock size={18} />}
              error={errors.startTime}
            />
          </div>
          
          <Select
            label="Grupamento"
            options={unitOptions}
            value={unitId}
            onChange={setUnitId}
            required
            fullWidth
            error={errors.unitId}
          />

          <Select
            label="Motorista"
            options={gcmOptions}
            value={driver}
            onChange={setDriver}
            required
            fullWidth
            error={errors.driver}
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Ocupantes
              {errors.crewMembers && (
                <span className="text-red-600 text-xs ml-2">{errors.crewMembers}</span>
              )}
            </label>
            <div className="space-y-2">
              {gcmOptions.map(gcm => (
                <label key={gcm.value} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={selectedCrewMembers.includes(gcm.value)}
                    onChange={() => handleCrewMemberChange(gcm.value)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span>{gcm.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Checklist da Viatura</h4>
            <div className="space-y-3 p-4 bg-gray-50 rounded-md">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={checklist.tires}
                  onChange={(e) => setChecklist(prev => ({ ...prev, tires: e.target.checked }))}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span>Pneus em bom estado</span>
              </label>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={checklist.windows}
                  onChange={(e) => setChecklist(prev => ({ ...prev, windows: e.target.checked }))}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span>Vidros íntegros</span>
              </label>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={checklist.oil}
                  onChange={(e) => setChecklist(prev => ({ ...prev, oil: e.target.checked }))}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span>Nível de óleo adequado</span>
              </label>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Avarias encontradas
                </label>
                <textarea
                  value={checklist.damages}
                  onChange={(e) => setChecklist(prev => ({ ...prev, damages: e.target.value }))}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
                  rows={3}
                  placeholder="Descreva qualquer avaria encontrada..."
                />
              </div>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Foto da Viatura
            </label>
            <div 
              className={`
                border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center
                ${photoUploaded ? 'border-green-300 bg-green-50' : 'border-gray-300 hover:border-blue-400'}
                transition-colors cursor-pointer
              `}
              onClick={handlePhotoUpload}
            >
              {photoUploaded ? (
                <>
                  <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center text-green-600 mb-2">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                    </svg>
                  </div>
                  <p className="text-sm font-medium text-green-600">Foto enviada com sucesso</p>
                  <p className="text-xs text-gray-500 mt-1">Clique para alterar a foto</p>
                </>
              ) : (
                <>
                  <Camera className="h-10 w-10 text-gray-400 mb-2" />
                  <p className="text-sm font-medium text-gray-700">Tire uma foto da viatura</p>
                  <p className="text-xs text-gray-500 mt-1">Clique para abrir a câmera</p>
                </>
              )}
            </div>
            {errors.photo && <p className="mt-1 text-sm text-red-600">{errors.photo}</p>}
          </div>
          
          <Input
            label="Observações"
            as="textarea"
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Informações adicionais sobre o turno..."
            fullWidth
          />
          
          {errors.submit && (
            <div className="bg-red-50 p-3 rounded-md text-red-700 text-sm">
              {errors.submit}
            </div>
          )}
        </CardContent>
        
        <CardFooter className="flex justify-end space-x-3">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isLoading}
          >
            Cancelar
          </Button>
          <Button
            type="submit"
            variant="primary"
            disabled={isLoading}
          >
            {isLoading ? 'Iniciando...' : 'Iniciar Turno'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default ShiftForm;
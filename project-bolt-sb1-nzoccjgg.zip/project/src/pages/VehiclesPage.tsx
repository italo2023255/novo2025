import React, { useState } from 'react';
import { Plus, FileText, Search } from 'lucide-react';
import { Vehicle } from '../types';
import { useVehicle } from '../context/VehicleContext';
import PageContainer from '../components/layout/PageContainer';
import VehicleCard from '../components/vehicle/VehicleCard';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Badge from '../ui/Badge';
import ShiftForm from '../components/shift/ShiftForm';
import EndShiftForm from '../components/shift/EndShiftForm';
import RefuelingForm from '../components/shift/RefuelingForm';
import ActiveShiftCard from '../components/shift/ActiveShiftCard';
import VehicleForm from '../components/vehicle/VehicleForm';

const VehiclesPage: React.FC = () => {
  const { vehicles, shifts, getVehicleById, getActiveShiftForVehicle, deleteVehicle } = useVehicle();
  
  const [selectedVehicleId, setSelectedVehicleId] = useState<string | null>(null);
  const [view, setView] = useState<'list' | 'start-shift' | 'end-shift' | 'refuel' | 'details' | 'new-vehicle'>('list');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filter, setFilter] = useState<'all' | 'available' | 'in-use' | 'maintenance'>('all');
  
  // Get selected vehicle and active shift if any
  const selectedVehicle = selectedVehicleId ? getVehicleById(selectedVehicleId) : null;
  const activeShift = selectedVehicleId ? getActiveShiftForVehicle(selectedVehicleId) : null;
  
  // Filter vehicles based on search query and status filter
  const filteredVehicles = vehicles.filter(vehicle => {
    const matchesSearch = searchQuery === '' || 
      vehicle.plateNumber.toLowerCase().includes(searchQuery.toLowerCase()) || 
      vehicle.model.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = filter === 'all' || vehicle.status === filter;
    
    return matchesSearch && matchesFilter;
  });
  
  // Handle vehicle selection
  const handleSelectVehicle = (vehicleId: string) => {
    setSelectedVehicleId(vehicleId);
    
    const vehicle = getVehicleById(vehicleId);
    if (!vehicle) return;
    
    const activeShift = getActiveShiftForVehicle(vehicleId);
    
    if (vehicle.status === 'available') {
      setView('start-shift');
    } else if (vehicle.status === 'in-use' && activeShift) {
      setView('details');
    }
  };
  
  // Handle back to list view
  const handleBackToList = () => {
    setView('list');
    setSelectedVehicleId(null);
  };
  
  // Handle new vehicle
  const handleNewVehicle = () => {
    setView('new-vehicle');
  };
  
  const handleNewVehicleComplete = () => {
    setView('list');
  };

  // Handle vehicle deletion
  const handleDeleteVehicle = async (vehicleId: string) => {
    try {
      await deleteVehicle(vehicleId);
    } catch (error) {
      alert('Erro ao excluir viatura: ' + (error as Error).message);
    }
  };
  
  // Handle shift actions
  const handleStartShiftComplete = () => {
    setView('list');
    setSelectedVehicleId(null);
  };
  
  const handleEndShift = () => {
    setView('end-shift');
  };
  
  const handleEndShiftComplete = () => {
    setView('list');
    setSelectedVehicleId(null);
  };
  
  const handleRefuel = () => {
    setView('refuel');
  };
  
  const handleRefuelComplete = () => {
    setView('details');
  };
  
  const handleAddPhoto = () => {
    // This would open a photo upload UI in a real app
    console.log('Add photo for vehicle:', selectedVehicleId);
  };
  
  // Render different views based on state
  const renderContent = () => {
    if (view === 'list') {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredVehicles.length === 0 ? (
            <div className="col-span-full flex justify-center items-center py-12">
              <div className="text-center">
                <SearchIcon size={48} className="mx-auto text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">Nenhuma viatura encontrada</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Tente ajustar seus filtros ou termos de busca.
                </p>
              </div>
            </div>
          ) : (
            filteredVehicles.map(vehicle => (
              <VehicleCard 
                key={vehicle.id}
                vehicle={vehicle}
                onSelect={handleSelectVehicle}
                onDelete={handleDeleteVehicle}
              />
            ))
          )}
        </div>
      );
    }
    
    if (view === 'new-vehicle') {
      return (
        <VehicleForm
          onComplete={handleNewVehicleComplete}
          onCancel={handleBackToList}
        />
      );
    }
    
    if (view === 'start-shift' && selectedVehicle) {
      return (
        <ShiftForm 
          vehicle={selectedVehicle}
          onSubmit={handleStartShiftComplete}
          onCancel={handleBackToList}
        />
      );
    }
    
    if (view === 'details' && selectedVehicle && activeShift) {
      return (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <Button variant="outline" onClick={handleBackToList}>
              Voltar para lista
            </Button>
          </div>
          
          <ActiveShiftCard 
            shift={activeShift}
            vehicle={selectedVehicle}
            onEnd={handleEndShift}
            onRefuel={handleRefuel}
            onAddPhoto={handleAddPhoto}
          />
        </div>
      );
    }
    
    if (view === 'end-shift' && selectedVehicle && activeShift) {
      return (
        <EndShiftForm 
          shift={activeShift}
          vehicle={selectedVehicle}
          onComplete={handleEndShiftComplete}
          onCancel={() => setView('details')}
        />
      );
    }
    
    if (view === 'refuel' && selectedVehicle && activeShift) {
      return (
        <RefuelingForm 
          shift={activeShift}
          vehicle={selectedVehicle}
          onComplete={handleRefuelComplete}
          onCancel={() => setView('details')}
        />
      );
    }
    
    return null;
  };
  
  // Custom action buttons for page header
  const renderActions = () => {
    if (view !== 'list') return null;
    
    return (
      <Button 
        variant="primary" 
        icon={<Plus size={16} />}
        onClick={handleNewVehicle}
      >
        Nova Viatura
      </Button>
    );
  };
  
  // Render filter buttons
  const renderFilters = () => {
    if (view !== 'list') return null;
    
    return (
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
        <div className="w-full sm:w-64">
          <Input
            placeholder="Buscar viatura..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            fullWidth
            icon={<Search size={18} />}
          />
        </div>
        
        <div className="flex space-x-2">
          <button
            className={`px-3 py-1 text-sm rounded-full transition-colors ${
              filter === 'all'
                ? 'bg-blue-100 text-blue-800'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            onClick={() => setFilter('all')}
          >
            Todas
          </button>
          <button
            className={`px-3 py-1 text-sm rounded-full transition-colors ${
              filter === 'available'
                ? 'bg-green-100 text-green-800'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            onClick={() => setFilter('available')}
          >
            Disponíveis
          </button>
          <button
            className={`px-3 py-1 text-sm rounded-full transition-colors ${
              filter === 'in-use'
                ? 'bg-blue-100 text-blue-800'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            onClick={() => setFilter('in-use')}
          >
            Em Uso
          </button>
          <button
            className={`px-3 py-1 text-sm rounded-full transition-colors ${
              filter === 'maintenance'
                ? 'bg-amber-100 text-amber-800'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            onClick={() => setFilter('maintenance')}
          >
            Manutenção
          </button>
        </div>
      </div>
    );
  };
  
  // Custom icon components
  const SearchIcon = (props: any) => {
    return (
      <svg 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 24 24" 
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        {...props}
      >
        <circle cx="11" cy="11" r="8" />
        <path d="m21 21-4.3-4.3" />
      </svg>
    );
  };
  
  return (
    <PageContainer 
      title={view === 'list' ? "Viaturas" : "Gerenciar Viatura"}
      actions={renderActions()}
    >
      {renderFilters()}
      {renderContent()}
    </PageContainer>
  );
};

export default VehiclesPage;
import React from 'react';
import { Calendar, AlertTriangle, CheckCircle2, Clock, Fuel, Car } from 'lucide-react';
import PageContainer from '../components/layout/PageContainer';
import Card, { CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { useVehicle } from '../context/VehicleContext';
import VehicleCard from '../components/vehicle/VehicleCard';
import ActiveShiftCard from '../components/shift/ActiveShiftCard';

interface DashboardCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  description?: string;
  trend?: 'up' | 'down' | 'neutral';
  className?: string;
}

const DashboardCard: React.FC<DashboardCardProps> = ({
  title,
  value,
  icon,
  description,
  trend,
  className = '',
}) => {
  return (
    <Card className={className}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <p className="text-2xl font-bold mt-1">{value}</p>
            {description && (
              <p className="text-sm text-gray-500 mt-1">
                {trend === 'up' && <span className="text-green-500">↑ </span>}
                {trend === 'down' && <span className="text-red-500">↓ </span>}
                {description}
              </p>
            )}
          </div>
          <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-700">
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const DashboardPage: React.FC = () => {
  const { vehicles, shifts, activeShift } = useVehicle();
  
  // Find active vehicle if there's an active shift
  const activeVehicle = activeShift 
    ? vehicles.find(v => v.id === activeShift.vehicleId) 
    : undefined;
  
  // Calculate dashboard metrics
  const availableVehicles = vehicles.filter(v => v.status === 'available').length;
  const inUseVehicles = vehicles.filter(v => v.status === 'in-use').length;
  const maintenanceVehicles = vehicles.filter(v => v.status === 'maintenance').length;
  const completedShifts = shifts.filter(s => s.status === 'completed').length;
  
  // Handle navigation to vehicle details
  const handleVehicleSelect = (vehicleId: string) => {
    console.log('Selected vehicle:', vehicleId);
    // In a real app, this would navigate to the vehicle details page
  };
  
  // For the sample implementation, these are just placeholder functions
  const handleEndShift = () => {
    console.log('End shift for vehicle:', activeVehicle?.id);
    // This would open the end shift form
  };
  
  const handleRefuel = () => {
    console.log('Refuel for vehicle:', activeVehicle?.id);
    // This would open the refueling form
  };
  
  const handleAddPhoto = () => {
    console.log('Add photo for vehicle:', activeVehicle?.id);
    // This would open the photo upload UI
  };
  
  return (
    <PageContainer title="Dashboard">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <DashboardCard 
          title="Viaturas Disponíveis"
          value={availableVehicles}
          icon={<CheckCircle2 size={24} />}
          description={`${Math.round((availableVehicles / vehicles.length) * 100)}% da frota`}
          trend="neutral"
        />
        <DashboardCard 
          title="Viaturas em Uso"
          value={inUseVehicles}
          icon={<Car size={24} />}
          description={`${inUseVehicles} turnos ativos`}
          trend="neutral"
        />
        <DashboardCard 
          title="Em Manutenção"
          value={maintenanceVehicles}
          icon={<AlertTriangle size={24} />}
          description="Previsto: 2 dias para conclusão"
          trend="down"
        />
        <DashboardCard 
          title="Turnos Completados"
          value={completedShifts}
          icon={<Calendar size={24} />}
          description="Últimos 30 dias"
          trend="up"
        />
      </div>
      
      {activeShift && activeVehicle && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Turno Ativo</h2>
          <ActiveShiftCard 
            shift={activeShift}
            vehicle={activeVehicle}
            onEnd={handleEndShift}
            onRefuel={handleRefuel}
            onAddPhoto={handleAddPhoto}
          />
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Viaturas Disponíveis</h2>
          <div className="grid grid-cols-1 gap-4">
            {vehicles
              .filter(v => v.status === 'available')
              .map(vehicle => (
                <VehicleCard 
                  key={vehicle.id}
                  vehicle={vehicle}
                  onSelect={handleVehicleSelect}
                />
              ))}
          </div>
        </div>
        
        <div>
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Indicadores de Desempenho</h2>
          <Card>
            <CardHeader>
              <CardTitle>Resumo da Frota</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm font-medium text-gray-500 mb-1">
                    <span>Consumo Médio de Combustível</span>
                    <span>9.8 km/l</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '70%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between text-sm font-medium text-gray-500 mb-1">
                    <span>Taxa de Utilização da Frota</span>
                    <span>{Math.round((inUseVehicles / (vehicles.length - maintenanceVehicles)) * 100)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-500 h-2 rounded-full" 
                      style={{ width: `${Math.round((inUseVehicles / (vehicles.length - maintenanceVehicles)) * 100)}%` }}>
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between text-sm font-medium text-gray-500 mb-1">
                    <span>Condição da Frota</span>
                    <span>{Math.round(((vehicles.length - maintenanceVehicles) / vehicles.length) * 100)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-amber-500 h-2 rounded-full" 
                      style={{ width: `${Math.round(((vehicles.length - maintenanceVehicles) / vehicles.length) * 100)}%` }}>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-gray-200">
                  <h4 className="text-sm font-medium text-gray-700 mb-3">Últimas Atividades</h4>
                  <div className="space-y-3">
                    <div className="flex">
                      <div className="mr-3 flex-shrink-0">
                        <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700">
                          <Fuel size={16} />
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-medium">GCM-1234 abastecida</p>
                        <p className="text-xs text-gray-500">Hoje, 09:45 - 45L, R$ 350,00</p>
                      </div>
                    </div>
                    <div className="flex">
                      <div className="mr-3 flex-shrink-0">
                        <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center text-green-700">
                          <CheckCircle2 size={16} />
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Turno finalizado - GCM-5678</p>
                        <p className="text-xs text-gray-500">Ontem, 18:30 - 8h de duração</p>
                      </div>
                    </div>
                    <div className="flex">
                      <div className="mr-3 flex-shrink-0">
                        <div className="h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-700">
                          <Clock size={16} />
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Manutenção programada</p>
                        <p className="text-xs text-gray-500">GCM-9012 - Próxima semana</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
};

export default DashboardPage;
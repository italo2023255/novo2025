import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { User, Lock } from 'lucide-react';
import LoadingSpinner from '../components/ui/LoadingSpinner';

const LoginPage: React.FC = () => {
  const { login, isLoading } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username || !password) {
      setError('Por favor, preencha todos os campos');
      return;
    }
    
    try {
      const success = await login(username, password);
      
      if (!success) {
        setError('Usuário ou senha inválidos');
      }
    } catch (err) {
      setError('Ocorreu um erro ao fazer login. Tente novamente mais tarde.');
    }
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-800 to-blue-900 flex items-center justify-center px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-lg shadow-xl overflow-hidden">
          <div className="px-6 py-8 sm:px-10">
            <div className="text-center mb-8">
              <div className="mx-auto h-14 w-14 rounded-full bg-blue-100 flex items-center justify-center">
                <svg
                  className="h-8 w-8 text-blue-800"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              </div>
              <h2 className="mt-4 text-2xl font-bold text-gray-900">Controle de Viaturas</h2>
              <p className="mt-1 text-sm text-gray-600">Guarda Civil Municipal</p>
            </div>
            
            {error && (
              <div className="mb-4 p-3 bg-red-50 text-red-700 text-sm rounded-md">
                {error}
              </div>
            )}
            
            <form className="space-y-6" onSubmit={handleSubmit}>
              <Input
                label="Nome de Usuário"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Seu nome de usuário"
                required
                fullWidth
                icon={<User size={18} />}
                autoComplete="username"
              />
              
              <Input
                label="Senha"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Sua senha"
                required
                fullWidth
                icon={<Lock size={18} />}
                autoComplete="current-password"
              />
              
              <div>
                <Button type="submit" variant="primary" fullWidth disabled={isLoading}>
                  {isLoading ? <LoadingSpinner size="sm" color="text-white" className="mr-2" /> : null}
                  {isLoading ? 'Entrando...' : 'Entrar'}
                </Button>
              </div>
            </form>
            
            <div className="mt-6">
              <p className="text-center text-sm text-gray-500">
                Credenciais de demonstração: <br />
                <span className="font-semibold">Usuário:</span> admin | <span className="font-semibold">Senha:</span> admin123
              </p>
            </div>
          </div>
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 sm:px-10">
            <p className="text-xs text-center text-gray-500">
              &copy; {new Date().getFullYear()} Guarda Civil Municipal. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
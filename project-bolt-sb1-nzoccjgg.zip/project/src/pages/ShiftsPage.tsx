import React, { useState } from 'react';
import { Calendar, Search, Filter, ChevronDown, ChevronUp } from 'lucide-react';
import { Shift, Vehicle } from '../types';
import { useVehicle } from '../context/VehicleContext';
import PageContainer from '../components/layout/PageContainer';
import Card, { CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Badge from '../components/ui/Badge';

const ShiftsPage: React.FC = () => {
  const { shifts, vehicles, getVehicleById } = useVehicle();
  
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'completed'>('all');
  const [dateRange, setDateRange] = useState<{ start: string, end: string }>({
    start: '',
    end: '',
  });
  const [expandedShifts, setExpandedShifts] = useState<Record<string, boolean>>({});
  
  // Sort shifts by start time in descending order (newest first)
  const sortedShifts = [...shifts].sort((a, b) => 
    new Date(b.startTime).getTime() - new Date(a.startTime).getTime()
  );
  
  // Filter shifts based on search, status filter, and date range
  const filteredShifts = sortedShifts.filter(shift => {
    // Status filter
    if (statusFilter === 'active' && shift.status !== 'active') return false;
    if (statusFilter === 'completed' && shift.status !== 'completed') return false;
    
    // Date range filter
    if (dateRange.start) {
      const startDate = new Date(dateRange.start);
      const shiftDate = new Date(shift.startTime);
      if (shiftDate < startDate) return false;
    }
    
    if (dateRange.end) {
      const endDate = new Date(dateRange.end);
      const shiftDate = new Date(shift.startTime);
      if (shiftDate > endDate) return false;
    }
    
    // Search query
    if (searchQuery) {
      const normalizedQuery = searchQuery.toLowerCase();
      const vehicle = getVehicleById(shift.vehicleId);
      
      return (
        shift.driverName.toLowerCase().includes(normalizedQuery) ||
        shift.unitName.toLowerCase().includes(normalizedQuery) ||
        shift.notes.toLowerCase().includes(normalizedQuery) ||
        (vehicle && (
          vehicle.plateNumber.toLowerCase().includes(normalizedQuery) ||
          vehicle.model.toLowerCase().includes(normalizedQuery)
        ))
      );
    }
    
    return true;
  });
  
  // Toggle shift expanded state
  const toggleShiftExpanded = (shiftId: string) => {
    setExpandedShifts(prev => ({
      ...prev,
      [shiftId]: !prev[shiftId],
    }));
  };
  
  // Format shift duration
  const formatShiftDuration = (shift: Shift) => {
    if (!shift.endTime) return 'Em andamento';
    
    const startTime = new Date(shift.startTime);
    const endTime = new Date(shift.endTime);
    const durationMs = endTime.getTime() - startTime.getTime();
    
    const hours = Math.floor(durationMs / (1000 * 60 * 60));
    const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}m`;
  };
  
  // Render shift status badge
  const renderStatusBadge = (status: 'active' | 'completed') => {
    return status === 'active' 
      ? <Badge variant="primary">Ativo</Badge>
      : <Badge variant="success">Concluído</Badge>;
  };
  
  // Render vehicle info
  const renderVehicleInfo = (vehicleId: string) => {
    const vehicle = getVehicleById(vehicleId);
    if (!vehicle) return 'Viatura não encontrada';
    
    return `${vehicle.model} (${vehicle.plateNumber})`;
  };
  
  // Render refuelings
  const renderRefuelings = (shift: Shift) => {
    if (shift.refuelings.length === 0) {
      return <p className="text-sm text-gray-500">Nenhum abastecimento registrado</p>;
    }
    
    return (
      <div className="space-y-2">
        {shift.refuelings.map(refueling => (
          <div key={refueling.id} className="border rounded p-2 text-sm">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-gray-500">Data:</span>{' '}
                {new Date(refueling.date).toLocaleString()}
              </div>
              <div>
                <span className="text-gray-500">KM:</span>{' '}
                {refueling.kmAtRefueling.toLocaleString()}
              </div>
              <div>
                <span className="text-gray-500">Litros:</span>{' '}
                {refueling.liters.toFixed(2)} L
              </div>
              <div>
                <span className="text-gray-500">Valor:</span>{' '}
                R$ {refueling.totalCost.toFixed(2)}
              </div>
              <div className="col-span-2">
                <span className="text-gray-500">Combustível:</span>{' '}
                {refueling.fuelType === 'gasoline' ? 'Gasolina' : 
                 refueling.fuelType === 'diesel' ? 'Diesel' : 'Etanol'}
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };
  
  // Render photos
  const renderPhotos = (shift: Shift) => {
    return (
      <div className="flex flex-wrap gap-2">
        {shift.photos.map(photo => (
          <div key={photo.id} className="w-20 h-20">
            <img 
              src={photo.url} 
              alt={photo.description} 
              className="w-full h-full object-cover rounded"
              title={`${photo.description} - ${new Date(photo.timestamp).toLocaleString()}`}
            />
          </div>
        ))}
      </div>
    );
  };
  
  return (
    <PageContainer title="Turnos">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div className="w-full md:w-64">
          <Input
            placeholder="Buscar turno..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            fullWidth
            icon={<Search size={18} />}
          />
        </div>
        
        <div className="flex flex-wrap gap-2">
          <Button 
            variant={statusFilter === 'all' ? 'primary' : 'outline'} 
            size="sm"
            onClick={() => setStatusFilter('all')}
          >
            Todos
          </Button>
          <Button 
            variant={statusFilter === 'active' ? 'primary' : 'outline'} 
            size="sm"
            onClick={() => setStatusFilter('active')}
          >
            Ativos
          </Button>
          <Button 
            variant={statusFilter === 'completed' ? 'primary' : 'outline'} 
            size="sm"
            onClick={() => setStatusFilter('completed')}
          >
            Concluídos
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            icon={<Calendar size={14} />}
          >
            Filtrar por Data
          </Button>
        </div>
      </div>
      
      <div className="space-y-4">
        {filteredShifts.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <div className="mx-auto w-12 h-12 text-gray-400">
              <Calendar size={48} />
            </div>
            <h3 className="mt-2 text-lg font-medium text-gray-900">Nenhum turno encontrado</h3>
            <p className="mt-1 text-sm text-gray-500">
              Tente ajustar seus filtros ou termos de busca.
            </p>
          </div>
        ) : (
          filteredShifts.map(shift => (
            <Card key={shift.id} className="overflow-hidden">
              <div 
                className="p-4 cursor-pointer hover:bg-gray-50 transition-colors"
                onClick={() => toggleShiftExpanded(shift.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-start">
                    <div className="mr-3">
                      <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700">
                        <Calendar size={20} />
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center">
                        <h3 className="text-lg font-medium text-gray-900 mr-2">
                          {renderVehicleInfo(shift.vehicleId)}
                        </h3>
                        {renderStatusBadge(shift.status)}
                      </div>
                      <p className="text-sm text-gray-500">
                        {new Date(shift.startTime).toLocaleString()} • {formatShiftDuration(shift)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <button
                      className="p-1 rounded-full hover:bg-gray-200 transition-colors"
                      onClick={() => toggleShiftExpanded(shift.id)}
                    >
                      {expandedShifts[shift.id] ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                    </button>
                  </div>
                </div>
              </div>
              
              {expandedShifts[shift.id] && (
                <CardContent className="border-t border-gray-200 pt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium text-gray-700 mb-2">Detalhes do Turno</h4>
                      <div className="space-y-2 text-sm">
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <span className="text-gray-500">Início:</span>{' '}
                            {new Date(shift.startTime).toLocaleString()}
                          </div>
                          <div>
                            <span className="text-gray-500">Término:</span>{' '}
                            {shift.endTime ? new Date(shift.endTime).toLocaleString() : 'Em andamento'}
                          </div>
                          <div>
                            <span className="text-gray-500">KM Inicial:</span>{' '}
                            {shift.startKm.toLocaleString()}
                          </div>
                          <div>
                            <span className="text-gray-500">KM Final:</span>{' '}
                            {shift.endKm ? shift.endKm.toLocaleString() : 'Em andamento'}
                          </div>
                          <div>
                            <span className="text-gray-500">Condutor:</span>{' '}
                            {shift.driverName}
                          </div>
                          <div>
                            <span className="text-gray-500">Grupamento:</span>{' '}
                            {shift.unitName}
                          </div>
                        </div>
                        
                        {shift.notes && (
                          <div className="mt-2">
                            <span className="text-gray-500">Observações:</span>
                            <p className="mt-1 p-2 bg-gray-50 rounded">{shift.notes}</p>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium text-gray-700 mb-2">Abastecimentos</h4>
                        {renderRefuelings(shift)}
                      </div>
                      
                      <div>
                        <h4 className="font-medium text-gray-700 mb-2">Fotos</h4>
                        {renderPhotos(shift)}
                      </div>
                    </div>
                  </div>
                </CardContent>
              )}
            </Card>
          ))
        )}
      </div>
    </PageContainer>
  );
};

export default ShiftsPage;
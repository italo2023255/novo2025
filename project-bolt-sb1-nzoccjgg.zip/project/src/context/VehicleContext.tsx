import React, { createContext, useContext, useState, useEffect } from 'react';
import { Vehicle, Shift, Refueling, Photo, Unit } from '../types';

interface VehicleContextType {
  vehicles: Vehicle[];
  shifts: Shift[];
  units: Unit[];
  activeShift: Shift | null;
  isLoading: boolean;
  startShift: (shiftData: Partial<Shift>) => Promise<Shift>;
  endShift: (shiftId: string, endData: { endTime: string; endKm: number; photos: Photo[] }) => Promise<Shift>;
  addRefueling: (shiftId: string, refueling: Partial<Refueling>) => Promise<Refueling>;
  addPhoto: (shiftId: string, photo: Partial<Photo>) => Promise<Photo>;
  getVehicleById: (id: string) => Vehicle | undefined;
  getShiftById: (id: string) => Shift | undefined;
  getActiveShiftForVehicle: (vehicleId: string) => Shift | undefined;
  addVehicle: (vehicleData: { model: string; plateNumber: string; currentKm: number }) => Promise<Vehicle>;
  deleteVehicle: (vehicleId: string) => Promise<void>;
}

// Mock data
const MOCK_VEHICLES: Vehicle[] = [
  {
    id: '1',
    plateNumber: 'GCM-1234',
    model: 'Toyota Hilux',
    status: 'available',
    currentKm: 45780,
    lastMaintenanceKm: 45000,
    lastMaintenanceDate: '2025-03-15',
  },
  {
    id: '2',
    plateNumber: 'GCM-5678',
    model: 'VTR02',
    status: 'in-use',
    currentKm: 32450,
    lastMaintenanceKm: 30000,
    lastMaintenanceDate: '2025-02-20',
  },
  {
    id: '3',
    plateNumber: 'GCM-9012',
    model: 'VTR01',
    status: 'maintenance',
    currentKm: 67890,
    lastMaintenanceKm: 65000,
    lastMaintenanceDate: '2025-04-05',
  },
];

const MOCK_UNITS: Unit[] = [
  { id: '1', name: 'Ronda Ostensiva', code: 'RO' },
  { id: '2', name: 'Patrulha Escolar', code: 'PE' },
  { id: '3', name: 'Grupo Tático', code: 'GT' },
  { id: '4', name: 'Administrativo', code: 'ADM' },
];

const MOCK_SHIFTS: Shift[] = [
  {
    id: '1',
    vehicleId: '2',
    startTime: '2025-04-10T08:00:00',
    endTime: null,
    startKm: 32450,
    endKm: null,
    driverId: '2',
    driverName: 'João Silva',
    crewMembers: [],
    unitId: '1',
    unitName: 'Ronda Ostensiva',
    status: 'active',
    notes: 'Patrulhamento na zona leste',
    checklist: {
      tires: true,
      windows: true,
      oil: true,
      damages: '',
    },
    refuelings: [],
    photos: [
      {
        id: '1',
        shiftId: '1',
        url: 'https://images.pexels.com/photos/2467285/pexels-photo-2467285.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        description: 'Foto inicial da viatura',
        timestamp: '2025-04-10T08:00:00',
        type: 'start-shift',
      },
    ],
  }
];

const VehicleContext = createContext<VehicleContextType | undefined>(undefined);

export const useVehicle = () => {
  const context = useContext(VehicleContext);
  if (context === undefined) {
    throw new Error('useVehicle must be used within a VehicleProvider');
  }
  return context;
};

export const VehicleProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [vehicles, setVehicles] = useState<Vehicle[]>(MOCK_VEHICLES);
  const [shifts, setShifts] = useState<Shift[]>(MOCK_SHIFTS);
  const [units] = useState<Unit[]>(MOCK_UNITS);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading data from API
    const loadData = async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setIsLoading(false);
    };
    
    loadData();
  }, []);
  
  const getVehicleById = (id: string) => {
    return vehicles.find(v => v.id === id);
  };
  
  const getShiftById = (id: string) => {
    return shifts.find(s => s.id === id);
  };
  
  const getActiveShiftForVehicle = (vehicleId: string) => {
    return shifts.find(s => s.vehicleId === vehicleId && s.status === 'active');
  };
  
  const activeShift = shifts.find(s => s.status === 'active') || null;
  
  const addVehicle = async (vehicleData: { model: string; plateNumber: string; currentKm: number }): Promise<Vehicle> => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const newVehicle: Vehicle = {
      id: `vehicle_${Date.now()}`,
      model: vehicleData.model,
      plateNumber: vehicleData.plateNumber,
      status: 'available',
      currentKm: vehicleData.currentKm,
      lastMaintenanceKm: vehicleData.currentKm,
      lastMaintenanceDate: new Date().toISOString().split('T')[0],
    };
    
    setVehicles(prev => [...prev, newVehicle]);
    
    setIsLoading(false);
    return newVehicle;
  };

  const deleteVehicle = async (vehicleId: string): Promise<void> => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Check if vehicle has active shifts
    const hasActiveShift = shifts.some(s => 
      s.vehicleId === vehicleId && s.status === 'active'
    );
    
    if (hasActiveShift) {
      throw new Error('Não é possível excluir uma viatura com turno ativo');
    }
    
    setVehicles(prev => prev.filter(v => v.id !== vehicleId));
    setShifts(prev => prev.filter(s => s.vehicleId !== vehicleId));
    
    setIsLoading(false);
  };
  
  const startShift = async (shiftData: Partial<Shift>): Promise<Shift> => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const newShift: Shift = {
      id: `shift_${Date.now()}`,
      vehicleId: shiftData.vehicleId || '',
      startTime: shiftData.startTime || new Date().toISOString(),
      endTime: null,
      startKm: shiftData.startKm || 0,
      endKm: null,
      driverId: shiftData.driverId || '',
      driverName: shiftData.driverName || '',
      crewMembers: shiftData.crewMembers || [],
      unitId: shiftData.unitId || '',
      unitName: shiftData.unitName || '',
      status: 'active',
      notes: shiftData.notes || '',
      checklist: shiftData.checklist || {
        tires: false,
        windows: false,
        oil: false,
        damages: '',
      },
      refuelings: [],
      photos: shiftData.photos || [],
    };
    
    // Update vehicle status
    setVehicles(prev => prev.map(v => 
      v.id === newShift.vehicleId 
        ? { ...v, status: 'in-use' } 
        : v
    ));
    
    // Add new shift
    setShifts(prev => [...prev, newShift]);
    
    setIsLoading(false);
    return newShift;
  };
  
  const endShift = async (
    shiftId: string, 
    endData: { endTime: string; endKm: number; photos: Photo[] }
  ): Promise<Shift> => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Find the shift to end
    const shiftToEnd = shifts.find(s => s.id === shiftId);
    
    if (!shiftToEnd) {
      setIsLoading(false);
      throw new Error('Turno não encontrado');
    }
    
    // Update the shift
    const updatedShift: Shift = {
      ...shiftToEnd,
      endTime: endData.endTime,
      endKm: endData.endKm,
      status: 'completed',
      photos: [...shiftToEnd.photos, ...endData.photos],
    };
    
    // Update shifts array
    setShifts(prev => 
      prev.map(s => s.id === shiftId ? updatedShift : s)
    );
    
    // Update vehicle status and KM
    setVehicles(prev => prev.map(v => 
      v.id === updatedShift.vehicleId
        ? { ...v, status: 'available', currentKm: endData.endKm }
        : v
    ));
    
    setIsLoading(false);
    return updatedShift;
  };
  
  const addRefueling = async (
    shiftId: string, 
    refueling: Partial<Refueling>
  ): Promise<Refueling> => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const newRefueling: Refueling = {
      id: `refuel_${Date.now()}`,
      shiftId,
      date: refueling.date || new Date().toISOString(),
      liters: refueling.liters || 0,
      totalCost: refueling.totalCost || 0,
      kmAtRefueling: refueling.kmAtRefueling || 0,
      fuelType: refueling.fuelType || 'gasoline',
      receiptPhoto: refueling.receiptPhoto,
    };
    
    // Add refueling to shift
    setShifts(prev => prev.map(s => 
      s.id === shiftId
        ? { ...s, refuelings: [...s.refuelings, newRefueling] }
        : s
    ));
    
    setIsLoading(false);
    return newRefueling;
  };
  
  const addPhoto = async (
    shiftId: string,
    photo: Partial<Photo>
  ): Promise<Photo> => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const newPhoto: Photo = {
      id: `photo_${Date.now()}`,
      shiftId,
      url: photo.url || '',
      description: photo.description || '',
      timestamp: photo.timestamp || new Date().toISOString(),
      type: photo.type || 'other',
    };
    
    // Add photo to shift
    setShifts(prev => prev.map(s => 
      s.id === shiftId
        ? { ...s, photos: [...s.photos, newPhoto] }
        : s
    ));
    
    setIsLoading(false);
    return newPhoto;
  };
  
  return (
    <VehicleContext.Provider value={{
      vehicles,
      shifts,
      units,
      activeShift,
      isLoading,
      startShift,
      endShift,
      addRefueling,
      addPhoto,
      getVehicleById,
      getShiftById,
      getActiveShiftForVehicle,
      addVehicle,
      deleteVehicle,
    }}>
      {children}
    </VehicleContext.Provider>
  );
};
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Mock user data (in a real app, this would come from an API/backend)
const MOCK_USERS = [
  {
    id: '1',
    username: 'admin',
    password: 'admin123', // In a real app, this would be hashed
    name: 'Administrador Sistema',
    role: 'admin'
  },
  {
    id: '2',
    username: 'DANTAS',
    password: 'DANTAS123', // In a real app, this would be hashed
    name: 'DANTAS',
    role: 'guard'
  },
  {
    id: '3',
    username: 'supervisor',
    password: 'supervisor123', // In a real app, this would be hashed
    name: 'Maria Oliveira',
    role: 'supervisor'
  },
  {
    id: '4',
    username: 'ITALO',
    password: 'ITALO123', // In a real app, this would be hashed
    name: 'ITALO',
    role: 'guard'
  }
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for saved user in localStorage (simulating persistent login)
    const savedUser = localStorage.getItem('gcm_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const foundUser = MOCK_USERS.find(u => 
      u.username === username && u.password === password
    );
    
    if (foundUser) {
      // Remove password before storing user data
      const { password: _, ...secureUserData } = foundUser;
      setUser(secureUserData as User);
      localStorage.setItem('gcm_user', JSON.stringify(secureUserData));
      setIsLoading(false);
      return true;
    } else {
      setIsLoading(false);
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('gcm_user');
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      isAuthenticated: !!user, 
      isLoading, 
      login, 
      logout 
    }}>
      {children}
    </AuthContext.Provider>
  );
};